
<?php

    $header = "Testing Line Notify";
    
    $firstname =$_POST['firstname'];
    $lastname =$_POST['lastname'];
    $fileToUpload =$_POST['fileToUpload'];

    $message =$header.
          
    "\n". "เบอร์โทรศัพท์: ".$firstname.
    "\n". "เบอร์โทรศัพท์: ".$lastname
     ;


            if (isset($_POST["submit"])){
                if($firstname <> "" ||  $lastname <>   "" ){
                    sendlinemesg();  
                    header('Content-Type: text/html; charset=utf8');
                    $res = notify_message($message);
                    echo "<script>alert('สมัครเรียบร้อย');</script>";  
                    
                    }else{
                        echo "<script>alert('กรอกข้อมูลให้ครบ');</script>";  
                        
                    }
            } 
    function sendlinemesg(){
        define('LINE_API',"https://notify-api.line.me/api/notify");
        define('LINE_TOKEN',"fljUWYWVBx3vNKWMvztGIxI0bEHBpbsXAvHWj7bzNve");
    
    
        function notify_message($message){
            $queryData = array('message' => $message);
            $queryData = http_build_query($queryData,'','&');
            $headerOptions = array(
                'http' => array(
                    'method' => 'POST',
                    'header' => "Content-Type: application/x-www-form-urlencoded\r\n"
                    ."Authorization: Bearer ".LINE_TOKEN."\r\n"
                    ."Content-Length: ".strlen($queryData)."\r\n",
                'content'=> $queryData
            )
        );
        $context = stream_context_create($headerOptions);
        $result = file_get_contents(LINE_API,FALSE, $context);
        $res = json_decode($result);
        return $res;

        }
    }
?>