<?php 
   $username = "root";
   $pass = "";
   $localhost = "localhost";
   $database = "bank";
   $mysqli = new mysqli($localhost,$username,$pass,$database);
   session_start();

   

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Purchase recycled junk shop</title>

    <!-- css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <!-- icon -->
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>

    <!-- ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


    <style>
        table {
            width: 100%;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
        }

        .tabConWrap {
            width: 98%;
            position: relative;
            margin: 10px auto 30px;
            border-bottom: 4px solid #39f;
            text-align: left;
        }

        .tabs {
            width: auto;
            height: 28px;
            margin: 0px 0px;
            padding: 0px 0px;
        }

        .tabs li {
            margin: 0px 2px 0px 0px;
            padding: 0px 0px;
            display: inline;
            font: bold 12px Arial, Sans-Serif;
        }

        .tabs li a {
            background-color: #39f;
            color: white;
            padding: 7px 10px;
            text-decoration: none;
            border: 1px solid #ccc;
            border-bottom: none;
            -webkit-border-radius: 5px 5px 0px 0px;
            -moz-border-radius: 5px 5px 0px 0px;
            border-radius: 5px 5px 0px 0px;
        }

        .tabs .currentTab {
            background-color: white;
            color: #999;
            position: relative;
            z-index: 7;
        }

        .tabContainer {
            padding: 10px;
            height: 300px;
            background-color: white;
            border: 1px solid #ccc;
            position: relative;
            margin-top: -3px;
            z-index: 2;
            overflow: hidden;
        }

        .tabContainer iframe {
            border: none;
            width: 100%;
            height: 100%;
        }

        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #fff;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidebar a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            color: #f1f1f1;
        }

        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        .openbtn {
            font-size: 20px;
            cursor: pointer;
            background-color: #111;
            color: white;
            padding: 10px 15px;
            border: none;
        }

        .openbtn:hover {
            background-color: #444;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        /* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
        @media screen and (max-height: 450px) {
            .sidebar {
                padding-top: 15px;
            }

            .sidebar a {
                font-size: 18px;
            }
        }
    </style>

</head>

<body>
    <div class="contain p-3" style="  background-color: #f8f9fa;">
        <nav class="navbar navbar-expand-lg navbar-light bg-light" align="center">
            <a href="#" onclick="openNav()" style=" position: absolute;top: 10px;left: 15px;">
                <img src="img/stack.png" width="50" alt="">
            </a>
            <a class="navbar-brand" href="#" align="center">
                <img src="img/recycle_icon.png" width="100" height="100" class="d-inline-block align-top" alt="">
                <br>
                <label>
                    ธนาคารขยะ มหาวิทยาลัยขอนแก่น <br>
                    วิทยาเขตหนองคาย
                </label>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ml-auto mr-auto">
                    <h2>ขายขยะ</h2>
                </div>
                <div class="navbar-nav ml-auto" align="center">
                    <label>ชื่อผู้ใช้ <?php echo $_SESSION['name']; ?>
                        <br>
                        <a href="Logout.php" class="text-dark">
                            ออกจากระบบ
                        </a>
                    </label>
                </div>
            </div>
        </nav>
        <div id="mySidebar" class="sidebar">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
            <a href="index.php">รับซื้อขยะ</a>
            <a href="withdraw.php">ถอนเงิน</a>
            <a href="sell_junk.php">ขายขยะ</a>
            <a href="historybuy_sell.php">สรุปการซื้อขาย</a>
            <a href="account.php">บัญชี</a>
            <a href="junk_left_page.php">คลังขยะ</a>
            <a href="garbage_depot.php">ข้อมูลขยะ</a>
            <a href="list_member.php">ดูรายชื่อสมาชิก</a>
            <a href="register_admin.php">สมัครผู้ดูแล</a>
        </div>
        <!--<div class="row">
            <div class="col-sm-6">
                <form class="form-inline" action="sell_junk.php" method="post">
                    <span class="form-group w-25">
                    </span>
                    <div class="form-group mb-1">
                        <input type="text" style="text-align:right;" readonly class="form-control-plaintext"
                            value="เบอร์โทรศัพท์">
                    </div>
                    <div class="form-group mx-sm-2 mb-2">
                        <input type="text" class="form-control" minlength="10" maxlength="10"
                            onkeypress="return onlyNumberKey(event)" name="phone" required>
                    </div>
                    <button type="submit" class="btn btn-primary mb-2"><i class='fas fa-search'></i></button>
                </form>
            </div>
            <div class="col-sm-6 pl-5">
                <?php ?> /*
                   if(isset($_POST['phone'])){
                      $phone = $_POST['phone']; 
                      $select = "SELECT * FROM seller WHERE phone_sell='$phone'";
                      $result = mysqli_query($mysqli,$select);
                      if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_array($result)){
                           $show = $row['name_sell'];
                        }
                      }else{
                           $show = "ไม่มีชื่อนี้ในระบบ";
                      }
                   }
                   else{
                       $show = "ค้นหาชื่อ";
                   }
                ?>
                <label>ชื่อ-นามสกุล&emsp;<?php echo  $show; ?></label>
            </div>
        </div>-->
        <div class="row">
            <div class="col-sm-8" align="center">
                <table style="border:1px solid #dee2e6;">
                    <thead>
                        <tr>
                            <th><a href="sell_page/sell_paper_type.php" class="btn" target="myFrame">กระดาษ</a></th>
                            <th><a href="sell_page/sell_metal_type.php" class="btn" target="myFrame">โลหะ</a></th>
                            <th><a href="sell_page/sell_plastic_type.php" class="btn" target="myFrame">พลาสติก</a></th>
                            <th><a href="sell_page/sell_glass_type.php" class="btn" target="myFrame">แก้ว</a></th>
                            <th><a href="sell_page/sell_bottle_cap_type.php" class="btn" target="myFrame">ฝาขวด</a></th>
                        </tr>
                    </thead>
                </table>
                <iframe src="sell_page/sell_paper_type.php" width="100%" height="550" name="myFrame">
                    <p>Your browser does not support iframes.</p>
                </iframe>
                <button class="btn btn-block btn-danger" id="clearTable">ล้าง</button>
            </div>

            <div class="col-sm-4 border pb-5" align="center">
                <table>
                    <thead style="border-bottom:1px solid gray;">
                        <tr>
                            <th>ลำดับ</th>
                            <th>ชื่อสินค้า</th>
                            <th>จำนวน/กก.</th>
                            <th>มูลค่า</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total_price = 0;
                            $i = 0;
                            $sql = "SELECT * FROM cart 
                            INNER JOIN product_junk ON cart.junk_id = product_junk.id
                            WHERE cart.status_buy=0";
                            $result = mysqli_query($mysqli,$sql);
                            while($row = mysqli_fetch_array($result)){
                            $i++;
                            $total_price += ($row['price_junk']*$row['total_junk']); 
                        ?>
                        <tr>
                            <td><?php echo $i;?></td>
                            <td><?php echo $row['type_junk'];?></td>
                            <td><?php echo $row['total_junk']; ?></td>
                            <td><?php echo $row['price_junk'].'*'.($row['price_junk']*$row['total_junk']); ?></td>
                        </tr>

                        <?php }?>
                    </tbody>
                </table>
                <hr>
                <label>รวม&emsp;&emsp;<?php echo $total_price; ?>&emsp;&emsp;บาท</label>
                <hr>
                <botton class="btn btn-block btn-primary" id="save_btn" onclick="pay(<?php echo $total_price; ?>)">
                    บันทึก
                </botton>
            </div>
        </div>
    </div>
    <script>
        function onlyNumberKey(evt) {

            // Only ASCII charactar in that range allowed 
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }

        function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }

        function pay(total) {

            $.ajax({
                url: "database/pay_cart.php",
                type: "POST",
                data: {
                    total: total,
                    type_trade:"ขายขยะ",
                    user_name:"",
                    user_id:-1,
                },
                cache: false,
                success: function (dataResult) {
                    var dataResult = JSON.parse(dataResult);
                    if (dataResult.statusCode == 200) {

                    } else if (dataResult.statusCode == 201) {
                        alert("Error occured !");
                    }else if (dataResult.statusCode == 202) {
                        alert("กรุณาเลือกลูกค้า !");
                    }


                }
            });

        }

        $("#clearTable").click(function () {
            $.ajax({
                url: "database/clear_cart.php",
                type: "POST",
                cache: false,
                success: function (dataResult) {
                    var dataResult = JSON.parse(dataResult);
                    if (dataResult.statusCode == 200) {

                    } else if (dataResult.statusCode == 201) {
                        alert("Error occured !");
                    }

                }
            });

        });
    </script>
</body>

</html>