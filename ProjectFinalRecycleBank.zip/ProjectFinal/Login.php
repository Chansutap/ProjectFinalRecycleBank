<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <!-- css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>

    <!-- ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <style>
        form {
            width: 350px;
            background-color: rgb(234 251 245);
            border: 2px solid black;
        }

        .btn {
            color: white;
        }

        a {
            color: black;
        }
    </style>
</head>

<body class="container">
    <div class="row pt-5" align="center">
        <div class="col-sm-12 col-md-12">
            <form action="database/check_Login.php" method="post" class="p-2">
                <img src="img/recycle_icon.png" width="100" height="100" class="d-inline-block align-top" alt="">
                <br>
                <label align="center">ธนาคารขยะ มหาวิทยาลัยขอนแก่น <br>วิทยาเขตหนองคาย</label>
                <input type="text" class="form-control" name="username" placeholder="Username" id="username">
                <br>
                <input type="password" class="form-control" name="password" placeholder="Password" id="password">
                <br>
                <input type="checkbox" name="myCheckbox" value="lsRememberMe" id="rememberMe">
                <label>Remember Me</label>
                <br>
                <a href="#">Forget password ?</a>
                <br>
                <button class="btn btn-primary mt-3 p-2 pl-5 pr-5" onclick="lsRememberMe()">Login</button>
            </form>
        </div>
    </div>
    <script>
        const rmCheck = document.getElementById("rememberMe"),
            usernameInput = document.getElementById("username"),
            passwordInput = document.getElementById("password");


        if (localStorage.checkbox && localStorage.checkbox !== "") {
            rmCheck.setAttribute("checked", "checked");
            usernameInput.value = localStorage.username;
            passwordInput.value = localStorage.password;
        } else {
            rmCheck.removeAttribute("checked");
            usernameInput.value = "";
            passwordInput.value = "";
        }

        function lsRememberMe() {
            if (rmCheck.checked && usernameInput.value !== "") {
                localStorage.username = usernameInput.value;
                localStorage.checkbox = rmCheck.value;
                localStorage.password = passwordInput.value;
            } else {
                localStorage.username = "";
                localStorage.checkbox = "";
                localStorage.password = "";
            }
        }
    </script>
</body>

</html>