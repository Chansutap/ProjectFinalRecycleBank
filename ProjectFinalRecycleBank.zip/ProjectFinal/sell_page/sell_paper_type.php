<?php 
   $username = "root";
   $pass = "";
   $localhost = "localhost";
   $database = "bank";
   $mysqli = new mysqli($localhost,$username,$pass,$database);
   session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Paper</title>
    <!-- css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>

    <!-- ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>

<body>
    <div class="pl-2 pr-2 mt-3" style="background-color: #f8f9fa;">
        <table class="table table-sm table-bordered">
            <thead>
                <tr>
                    <th>รหัส</th>
                    <th>ชนิดขยะ</th>
                    <th>รายละเอียด</th>
                    <th>ราคา</th>
                    <th style="width:20px;">น้ำหนัก/กก.</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php 
                   $sql = "SELECT * FROM product_junk 
                    INNER JOIN left_junk ON product_junk.id=left_junk.junk_id 
                    WHERE product_junk.category_junk='กระดาษ' AND left_junk.total_left > 0";
                   $result = mysqli_query($mysqli,$sql);
                   while($row = mysqli_fetch_array($result)){
                ?>
                <tr>
                    <td style="display:none;"><input type="hidden" id="id" value="<?php echo $row['junk_id']; ?>"/></td>
                    <td><?php echo $row['id_junk'];?></td>
                    <td><?php echo $row['type_junk'];?></td>
                    <td><?php echo $row['detail_junk'];?></td>
                    <td><input type="number" min="0.01" style="width:100px;" step="0.01" id="price" required /></td>
                    <td><input type="number" min="0.01" style="width:100px;" step="0.01" id="number" required /></td>
                    <td><button class="btn btn-warning" id="butsave">เลือก</button></td>
                </tr>
                <?php }?>
            </tbody>
        </table>

    </div>
    <script>
        $("button").click(function () {
            var $row = $(this).closest('tr');
            var number = $row.find('#number').val();
            var total_plus = $row.find("#price").val();
            var tdIn = $row.find('#id').val();
            var total = total_plus*number;
             if (number >= 0.01) {
                //alert(tdIn); 
                check(parseInt(tdIn),parseFloat(total_plus).toFixed(2),parseFloat(number).toFixed(2));          
                //insert(parseInt(tdIn),parseInt(number,10)); //แก้
            }
            else{
                alert("ใส่จำนวน");
            }
        });


        function check(id,total,number) {
                $.ajax({
                    url: "../database/check_num_junk_choose.php",
                    type: "POST",
                    data: {
                        id: id,
                        total:total,
                        number:number
                    },
                    cache: false,
                    success: function (dataResult) {
                        var dataResult = JSON.parse(dataResult);
                        if (dataResult.statusCode == 200) {
                            insert(parseInt(id),parseFloat(total).toFixed(2),parseFloat(number).toFixed(2));
                            
                        } else if (dataResult.statusCode == 201) {
                            alert("Error occured !");
                        }
                        else if(dataResult.statusCode == 202){
                            alert("ใส่เกินจำนวน")
                        }

                    }
                });
         
        }

        function insert(id,total,number) {
                $.ajax({
                    url: "../database/insert_cart.php",
                    type: "POST",
                    data: {
                        id: id,
                        total:total,
                        number:number
                    },
                    cache: false,
                    success: function (dataResult) {
                        var dataResult = JSON.parse(dataResult);
                        if (dataResult.statusCode == 200) {
                            
                        } else if (dataResult.statusCode == 201) {
                            alert("Error occured !");
                        }

                    }
                });
         
        }
    </script>
</body>

</html>