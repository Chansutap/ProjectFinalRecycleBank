<?php 
   $username = "root";
   $pass = "";
   $localhost = "localhost";
   $database = "bank";
   $mysqli = new mysqli($localhost,$username,$pass,$database);
   session_start();

   $id = $_GET["id"];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Purchase recycled junk shop</title>

    <!-- css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
    <!-- icon -->
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>

    <!-- ajax -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- datetime -->
    <script src='js/jquery.js'></script>
    <script src='js/jquery.datetimepicker.full.js'></script>
    <script src='js/jquery.datetimepicker.full.min.js'></script>
    <link rel="stylesheet" href="js/jquery.datetimepicker.min.css">
    <script src='js/jquery.datetimepicker.min.js'></script>

    <style>
        table {
            width: 100%;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
        }

        .tabConWrap {
            width: 98%;
            position: relative;
            margin: 10px auto 30px;
            border-bottom: 4px solid #39f;
            text-align: left;
        }

        .tabs {
            width: auto;
            height: 28px;
            margin: 0px 0px;
            padding: 0px 0px;
        }

        .tabs li {
            margin: 0px 2px 0px 0px;
            padding: 0px 0px;
            display: inline;
            font: bold 12px Arial, Sans-Serif;
        }

        .tabs li a {
            background-color: #39f;
            color: white;
            padding: 7px 10px;
            text-decoration: none;
            border: 1px solid #ccc;
            border-bottom: none;
            -webkit-border-radius: 5px 5px 0px 0px;
            -moz-border-radius: 5px 5px 0px 0px;
            border-radius: 5px 5px 0px 0px;
        }

        .tabs .currentTab {
            background-color: white;
            color: #999;
            position: relative;
            z-index: 7;
        }

        .tabContainer {
            padding: 10px;
            height: 300px;
            background-color: white;
            border: 1px solid #ccc;
            position: relative;
            margin-top: -3px;
            z-index: 2;
            overflow: hidden;
        }

        .tabContainer iframe {
            border: none;
            width: 100%;
            height: 100%;
        }

        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #fff;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidebar a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidebar a:hover {
            color: #f1f1f1;
        }

        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        .openbtn {
            font-size: 20px;
            cursor: pointer;
            background-color: #111;
            color: white;
            padding: 10px 15px;
            border: none;
        }

        .openbtn:hover {
            background-color: #444;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        /* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
        @media screen and (max-height: 450px) {
            .sidebar {
                padding-top: 15px;
            }

            .sidebar a {
                font-size: 18px;
            }
        }
    </style>

</head>

<body style="  background-color: #f8f9fa;">
    <div class="contain p-3" style="  background-color: #f8f9fa;">
        <nav class="navbar navbar-expand-lg navbar-light bg-light" align="center">
            <a href="#" onclick="openNav()" style=" position: absolute;top: 10px;left: 15px;">
                <img src="img/stack.png" width="50" alt="">
            </a>
            <a class="navbar-brand" href="#" align="center">
                <img src="img/recycle_icon.png" width="100" height="100" class="d-inline-block align-top" alt="">
                <br>
                <label>
                    ธนาคารขยะ มหาวิทยาลัยขอนแก่น <br>
                    วิทยาเขตหนองคาย
                </label>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ml-auto mr-auto">
                    <h2>สมัครสมาชิก</h2>
                </div>
                <div class="navbar-nav ml-auto" align="center">
                    <label>ชื่อผู้ใช้ <?php echo $_SESSION['name']; ?>
                        <br>
                        <a href="Logout.php" class="text-dark">
                            ออกจากระบบ
                        </a>
                    </label>
                </div>
            </div>
        </nav>
        <div id="mySidebar" class="sidebar">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
            <a href="index.php">รับซื้อขยะ</a>
            <a href="withdraw.php">ถอนเงิน</a>
            <a href="sell_junk.php">ขายขยะ</a>
            <a href="historybuy_sell.php">สรุปการซื้อขาย</a>
            <a href="account.php">บัญชี</a>
            <a href="junk_left_page.php">คลังขยะ</a>
            <a href="garbage_depot.php">ข้อมูลขยะ</a>
            <a href="list_member.php">ดูรายชื่อสมาชิก</a>
            <a href="register_admin.php">สมัครผู้ดูแล</a>
        </div>
        <h4 align="center">แก้ไขรายชื่อสมาชิกธนาคารขยะ NKC</h4>
        <div class="row" align="center">
            <div class="col-sm-12 col-md-12">
                <form action="database/edit_register_customer.php" method="post" style="width:550px;">
                <?php 
                  $select = "SELECT * FROM seller WHERE id=$id";
                  $query = mysqli_query($mysqli,$select);
                  while($row = mysqli_fetch_array($query)){
                ?>
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="text" class="form-control" name="name" placeholder="ชื่อนาม-สกุล" value="<?php echo $row['name_sell']; ?>" required>
                    <br>
                    <input type="tel" onkeypress="return onlyNumberKey(event)" class="form-control" name="phone" value="<?php echo $row["phone_sell"];?>"
                         minlength="10" maxlength="10" placeholder="เบอร์โทร" required>
                    <br>
                   <!-- <select class="form-control" name="sex" id="" required>
                        <option value="male">ชาย</option>
                        <option value="female">หญิง</option>
                    </select>
                    <br>
                    <input type="text" class="form-control" name="date" id="datetimepicker"
                        placeholder="วันเกิด วว/ดด/ปป" required readonly>-->
                    <div class="row" align="center">
                        <div class="col-sm-6 mt-5 pr-5" align="right">
                            <input type="submit" class="btn btn-primary pl-5 pr-5" value="ยืนยันการสมัคร">
                        </div>
                        <div class="col-sm-6 mt-5 pl-5" align="left">
                            <a href="list_member.php" class="btn btn-danger pl-5 pr-5">ยกเลิก</a>
                        </div>
                    </div>
                <?php }?>
                </form>
            </div>
        </div>
    </div>
    <script>
        function onlyNumberKey(evt) {

            // Only ASCII charactar in that range allowed 
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }
        $(document).ready(function () {
            $.datetimepicker.setLocale('th');
            $('#datetimepicker').datetimepicker({
                timepicker: false,
                format: 'Y-m-d',
                yearOffset: 543
            });
        });

        function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
    </script>
</body>

</html>