<?php 
   include('data_config.php');
   
   $category_junk = $_POST['category_junk'];
   $id_junk = $_POST['id_junk'];
   $type_junk = $_POST['type_junk'];
   $detail_junk = $_POST['detail_junk'];
   $cost_member = $_POST['cost_member'];
   
   $insert = "INSERT INTO product_junk VALUES(NULL,'$category_junk','$id_junk','$type_junk','$detail_junk',$cost_member)";

   if(mysqli_query($mysqli,$insert)){

    $select = "SELECT * FROM product_junk ORDER BY id DESC LIMIT 1";
    $query = mysqli_query($mysqli,$select);
    if($query){
       while($row = mysqli_fetch_array($query)){
          $id = $row["id"];
       } 
       $insert = "INSERT INTO left_junk VALUES(NULL,$id,0)";
       if(mysqli_query($mysqli,$insert)){
         echo "<script>
         alert('เพิ่มข้อมูลรีบร้อย !!!!');
         window.location.href='../garbage_depot.php'; 
         </script>";
       }
    }  
    
   }
   else{
    echo "<script>
    alert('กรอกข้อมูลให้ถูกต้อง !!!!');
    window.location.href='../insert_junk.php'; 
    </script>"; 
   }

   exit;
?>