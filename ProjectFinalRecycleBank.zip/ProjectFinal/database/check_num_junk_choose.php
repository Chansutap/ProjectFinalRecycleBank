<?php 
   include('data_config.php');
    
   $id = $_POST["id"];
   $num = $_POST["total"];
   $total = $_POST["number"];


   $select = "SELECT * FROM left_junk WHERE junk_id=$id";
   $query = mysqli_query($mysqli,$select);
   if($query){
      while($row = mysqli_fetch_array($query)){
          $number = $row["total_left"];
      }
      if($total > $number){
         echo json_encode(array("statusCode"=>202));
      }
      else{
        echo json_encode(array("statusCode"=>200));

      }
   }
   else{
     echo json_encode(array("statusCode"=>201));
   }
   exit;

?>