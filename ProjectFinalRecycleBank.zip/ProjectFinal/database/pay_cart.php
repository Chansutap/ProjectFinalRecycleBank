<?php 
   session_start();

   include('data_config.php');
   $total = $_POST['total'];
   $type_trade = $_POST['type_trade'];
   $user_id = $_POST['user_id'];
  
 
   $user_name = $_POST["user_name"];
   $date = date("Y-m-d");
   $date_ex = explode("-",$date);
   $datadate = ($date_ex[0]+543)."-".$date_ex[1]."-".$date_ex[2];
   $buyer_id = $_SESSION["id"];
   $type_user = $type_trade.$user_name;
   
   if($user_id != ""){

   $select =  "SELECT * FROM cart WHERE status_buy=0";
   $query = mysqli_query($mysqli,$select);
   if($query){
   while($row = mysqli_fetch_array($query)){
       $id = $row['id'];
       $product_id = $row['junk_id'];
       $junk_left = $row["total_junk"];
       $insert = "INSERT INTO buysuccess VALUES(NULL,'$type_trade','$id','$total','$datadate', $buyer_id)"; 
       if(mysqli_query($mysqli,$insert)){
         if($type_trade == "ซื้อขยะ"){ 
            $select_left = "SELECT * FROM left_junk WHERE junk_id=$product_id";
            $show_info = mysqli_query($mysqli,$select_left);
            $countrow = mysqli_num_rows($show_info);
            if($countrow >= 1){
            while($show = mysqli_fetch_array($show_info)){
               $left_total = $show["total_left"]+$junk_left;
            }
            $update = "UPDATE left_junk SET total_left=$left_total WHERE junk_id=$product_id";
            mysqli_query($mysqli,$update);
            }
            else{
               $update = "INSERT INTO  left_junk value (NULL,$product_id,$junk_left)";
               mysqli_query($mysqli,$update);
            }
         }
         else if($type_trade == "ขายขยะ"){
          $select_left = "SELECT * FROM left_junk WHERE junk_id=$product_id";
          $show_info = mysqli_query($mysqli,$select_left);
          $countrow = mysqli_num_rows($show_info);
          if($countrow >= 1){
          while($show = mysqli_fetch_array($show_info)){
             $left_total = $show["total_left"]-$junk_left;
          }
          $update = "UPDATE left_junk SET total_left=$left_total WHERE junk_id=$product_id";
          mysqli_query($mysqli,$update);
         }
         }else{
            $update = "INSERT INTO left_junk value (NULL,$product_id,$junk_left)";
            mysqli_query($mysqli,$update);
         }
       }
   }

   $select1 = "SELECT * FROM account_bank ORDER BY id DESC LIMIT 1";
   $query_show = mysqli_query($mysqli,$select1);
   $num_row = mysqli_num_rows($query_show);
   if($num_row >= 1){
      while($row = mysqli_fetch_array($query_show)){
         if($type_trade == "ซื้อขยะ"){ 
              $total_left = $row["left_money"]-$total;   
              $insert_acc = "INSERT INTO account_bank VALUES(NULL,'$type_user',0,'$total','$total_left','$datadate',$buyer_id)";
              mysqli_query($mysqli,$insert_acc );
         }
         else if($type_trade == "ขายขยะ"){
             $total_left = $row["left_money"]+$total;   
             $insert_acc = "INSERT INTO account_bank VALUES(NULL,'$type_user','$total',0,'$total_left','$datadate',$buyer_id)";
             mysqli_query($mysqli,$insert_acc );
         }
     }  
   }else if($num_row == 0){
      if($type_trade == "ซื้อขยะ"){
         $total_left = 0-$total;   
         $insert_acc = "INSERT INTO account_bank VALUES(NULL,'$type_user',0,'$total','$total_left','$datadate',$buyer_id)";
         mysqli_query($mysqli,$insert_acc );
       }
       else if($type_trade == "ขายขยะ"){
         $total_left = 0+$total;   
         $insert_acc = "INSERT INTO account_bank VALUES(NULL,'$type_user','$total',0,'$total_left','$datadate',$buyer_id)";
         mysqli_query($mysqli,$insert_acc );
      }
   }

   $select2 = "SELECT * FROM account_seller WHERE user_id=$user_id ORDER BY account_seller.id DESC LIMIT 1";
   $query_seller = mysqli_query($mysqli,$select2);
   $num_row2 = mysqli_num_rows($query_seller);
   if($num_row2 >= 1){
       while($row1 = mysqli_fetch_array($query_seller)){
         if($type_trade == "ซื้อขยะ"){ 
            $total_left = $row1["left_money"]+$total;   
            $insert_acc_sell = "INSERT INTO account_seller VALUES(NULL,$total,0,$total_left,'$datadate',$user_id)";
            mysqli_query($mysqli,$insert_acc_sell);
         }
       }
   }
   else{
      $total_left = 0+$total;   
      $insert_acc_sell = "INSERT INTO account_seller VALUES(NULL,$total,0,$total_left,'$datadate',$user_id)";
      mysqli_query($mysqli,$insert_acc_sell);
   }

  

 
    $sql = "UPDATE cart SET status_buy=1 WHERE status_buy=0";

    if(mysqli_query($mysqli,$sql)){
       echo json_encode(array("statusCode"=>200));
    }
    else{
         echo json_encode(array("statusCode"=>201));
    }
   }
   else{
      echo json_encode(array("statusCode"=>201));
   }
   }
   else{
      echo json_encode(array("statusCode"=>202));
   }
   

   mysqli_close($mysqli);



  

?>