<?php 
   include('data_config.php');

   $id = $_POST['id'];
   $total=  $_POST['total'];
  
   $status = 0;

   $oldtotal = 0;

   $select = "SELECT * FROM cart WHERE junk_id=$id AND status_buy=0";
   $show = mysqli_query($mysqli,$select);
   if(mysqli_num_rows($show) > 0){
       while($row = mysqli_fetch_array($show)){
            $oldtotal = $row['total_junk'];
       }
       $total += $oldtotal;
       if(isset($_POST['number'])){
         $number = $_POST['number'];
         $sql = "UPDATE cart SET total_junk=$number WHERE junk_id=$id";
      }
      else{
         $sql = "UPDATE cart SET total_junk=$total WHERE junk_id=$id";

      }
      
       
   }
   else if(mysqli_num_rows($show) <= 0){
      if(isset($_POST['number'])){
         $number = $_POST['number'];
         $sql = "INSERT INTO cart VALUES ( null, '$id' ,'$total', '$number' , '$status' )";
      }
         else{
            $sql = "INSERT INTO cart VALUES ( null, '$id' ,'', '$total' , '$status' )";
      }
  
   }
   
   if(mysqli_query($mysqli,$sql)){
      echo json_encode(array("statusCode"=>200));
   }
   else{
		echo json_encode(array("statusCode"=>201));
   }
   
   mysqli_close($mysqli);

?>