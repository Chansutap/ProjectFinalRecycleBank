<?php 
  session_start();
  include('data_config.php');
  
  $header = "มหาวิทยาลัยขอนแก่นวิทยาเขตหนองคาย";
  
  $user_id = $_POST["user_id"];
  $date = date("Y-m-d");
  $date_ex = explode("-",$date);
  $datadate = ($date_ex[0]+543)."-".$date_ex[1]."-".$date_ex[2];
  $buyer_id = $_SESSION["id"];
  $total = $_POST["total"];

  
  




  if($user_id != ""){

$message =$header.
            "\n". "วันที่: ".$date .
            "\n". "รหัสผู้ขาย: ".$user_id .
            "\n". "รหัสผู้ขาย: ".$buyer_id .
            "\n". "จำนวนที่ถอน: ".$total ."\r"."บาท";

  
    
    $select1 = "SELECT * FROM withdraw";
    $query_show = mysqli_query($mysqli,$select1);
    $num_row = mysqli_num_rows($query_show);
    if($num_row >= 1){
        $insert_wd = "INSERT INTO withdraw VALUES(NULL,'$datadate ',$total,$buyer_id,$user_id)";
        mysqli_query($mysqli,$insert_wd );


        sendlinemesg();  
        header('Content-Type: text/html; charset=utf8');
        $res = notify_message($message);
       
    }else if($num_row == 0){
          $insert_wd = "INSERT INTO withdraw VALUES(NULL,'$datadate ',$total,$buyer_id,$user_id)";
          mysqli_query($mysqli,$insert_wd );
    }

 
    $select2 = "SELECT * FROM account_seller WHERE user_id=$user_id ORDER BY account_seller.id DESC LIMIT 1";
    $query_seller = mysqli_query($mysqli,$select2);
    $num_row2 = mysqli_num_rows($query_seller);
    if($num_row2 >= 1){
        while($row1 = mysqli_fetch_array($query_seller)){
             $total_left = $row1["left_money"]-$total;   
             $insert_acc_sell = "INSERT INTO account_seller VALUES(NULL,0,$total,$total_left,'$datadate',$user_id)";
             mysqli_query($mysqli,$insert_acc_sell); 


             sendlinemesg();  
                    header('Content-Type: text/html; charset=utf8');
                    $res = notify_message($message);
            
             
             
        }
     }
    }
    else{
       echo json_encode(array("statusCode"=>202));

    }



    function sendlinemesg(){
      define('LINE_API',"https://notify-api.line.me/api/notify");
      define('LINE_TOKEN',"L4hPwRDMY6BDK21H7S6FXmmybTS0Pr592xKVlnmPM6T");
  
  
      function notify_message($message){
          $queryData = array('message' => $message);
          $queryData = http_build_query($queryData,'','&');
          $headerOptions = array(
              'http' => array(
                  'method' => 'POST',
                  'header' => "Content-Type: application/x-www-form-urlencoded\r\n"
                  ."Authorization: Bearer ".LINE_TOKEN."\r\n"
                  ."Content-Length: ".strlen($queryData)."\r\n",
              'content'=> $queryData
          )
      );
      $context = stream_context_create($headerOptions);
      $result = file_get_contents(LINE_API,FALSE, $context);
      $res = json_decode($result);
      return $res;

      }
  }
    mysqli_close($mysqli);

    


?>
