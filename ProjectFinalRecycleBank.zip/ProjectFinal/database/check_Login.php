<?php 
   session_start();
   include('data_config.php');
    
   $username = $_POST['username'];
   $password = $_POST['password'];

   $select = "SELECT * FROM buyer WHERE username_buyer='$username' AND password_buyer='$password'";

   $result = mysqli_query($mysqli,$select);
   $num_row = mysqli_num_rows($result);
   if($num_row == 1){
      $row = mysqli_fetch_array($result); 
      $_SESSION["name"] = $row["name_buyer"];
      $_SESSION["id"] =  $row["id"];
      header("location:../index.php");
   }
   else{
      session_destroy();
      echo "<script>
          alert('username or password is wrong !!!!');
          window.location.href='../Login.php'; 
      </script>";
   }
   exit;

?>