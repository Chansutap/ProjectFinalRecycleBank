<?php 
   include('data_config.php');
   
   $id = $_GET['id'];

   $del = "DELETE FROM product_junk WHERE id=$id";
   

   if(mysqli_query($mysqli,$del)){
    $del = "DELETE FROM left_junk WHERE junk_id=$id";
    if(mysqli_query($mysqli,$del)){
      echo "<script>
      alert('ลบรีบร้อย !!!!');
      window.location.href='../garbage_depot.php'; 
      </script>"; 
    }  
   }
   else{
    echo "<script>
    alert('ไม่สามารถลบได้ !!!!');
    window.location.href='../garbage_depot.php'; 
    </script>"; 
   }
   exit;
?>