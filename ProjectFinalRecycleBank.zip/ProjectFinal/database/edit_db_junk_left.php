<?php 
   include('data_config.php');

   $ID = $_POST['junk_id'];
   $left_number = $_POST['left_number'];
   
   $insert = "UPDATE left_junk SET  total_left=$left_number
   WHERE id=$ID";

   if(mysqli_query($mysqli,$insert)){
    echo "<script>
    alert('แก้ไขข้อมูลรีบร้อย !!!!');
    window.location.href='../junk_left_page.php'; 
    </script>"; 
   }
   else{
    echo "<script>
    alert('กรอกข้อมูลให้ถูกต้อง !!!!');
    window.location.href='../junk_left_page.php'; 
    </script>"; 
   }

   exit;
?>