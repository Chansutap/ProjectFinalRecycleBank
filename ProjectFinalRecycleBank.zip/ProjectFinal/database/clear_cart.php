<?php 
   include('data_config.php');

   $sql = "DELETE FROM cart WHERE status_buy=0";

   if(mysqli_query($mysqli,$sql)){
      echo json_encode(array("statusCode"=>200));
   }
   else{
		echo json_encode(array("statusCode"=>201));
   }
   mysqli_close($mysqli);

?>