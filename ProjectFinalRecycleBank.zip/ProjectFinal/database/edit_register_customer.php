<?php 
   include('data_config.php');

   $ID = $_POST['id'];
   $name = $_POST['name'];
   $phone = $_POST["phone"];
   
   
   $insert = "UPDATE seller SET name_sell='$name',phone_sell='$phone'
   WHERE id=$ID";

   if(mysqli_query($mysqli,$insert)){
    echo "<script>
    alert('แก้ไขข้อมูลรีบร้อย !!!!');
    window.location.href='../list_member.php'; 
    </script>"; 
   }
   else{
    echo "<script>
    alert('กรอกข้อมูลให้ถูกต้อง !!!!');
    window.location.href='../list_memberphp'; 
    </script>"; 
   }

   exit;
?>