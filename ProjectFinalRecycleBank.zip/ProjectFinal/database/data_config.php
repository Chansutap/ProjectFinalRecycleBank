<?php 
   $username = "root";
   $pass = "";
   $localhost = "localhost";
   $database = "bank";
   $mysqli = new mysqli($localhost,$username,$pass,$database);
?>