<?php 
   include('data_config.php');

   $ID = $_POST['id'];
   $category_junk = $_POST['category_junk'];
   $id_junk = $_POST['id_junk'];
   $type_junk = $_POST['type_junk'];
   $detail_junk = $_POST['detail_junk'];
   $cost_member = $_POST['cost_member'];
   
   $insert = "UPDATE product_junk SET category_junk='$category_junk',id_junk='$id_junk',type_junk='$type_junk',detail_junk='$detail_junk'
   ,member_junk=$cost_member
   WHERE id=$ID";

   if(mysqli_query($mysqli,$insert)){
    echo "<script>
    alert('แก้ไขข้อมูลรีบร้อย !!!!');
    window.location.href='../garbage_depot.php'; 
    </script>"; 
   }
   else{
    echo "<script>
    alert('กรอกข้อมูลให้ถูกต้อง !!!!');
    window.location.href='../insert_junk.php'; 
    </script>"; 
   }

   exit;
?>