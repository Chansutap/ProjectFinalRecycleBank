<?php 
   include('data_config.php');

   $name = $_POST['name'];
   $phone = $_POST['phone'];
   $sex = $_POST['sex'];
   $status = $_POST['status'];
   $username =  $_POST['username'];
   $password = $_POST['password'];
   $re_password = $_POST['re_password'];


   
   if($password == $re_password){


     $select = "SELECT * FROM buyer WHERE phone_buyer='$phone' OR username_buyer='$username'";
      $query = mysqli_query($mysqli,$select);

     if(mysqli_num_rows($query) <= 0){
    
       $insert = "INSERT INTO buyer VALUES(NULL,'$name','$sex','$status','$phone','$username','$password')";

        if(mysqli_query($mysqli,$insert))
        {
          header("location:../index.php");
        }
        else{
            echo "<script>
            alert('กรอกข้อมูลให้ถูกต้อง !!!!');
            window.location.href='../register_admin.php'; 
            </script>"; 
        }
        
      }
      else{
         echo "<script>
         alert('มีข้อมูลลูกค้าคนนี้อยู่แล้ว !!!!');
         window.location.href='../register_admin.php'; 
         </script>"; 

      }
   }
   else{
    echo "<script>
    alert('รหัสผ่านไม่ตรง !!!!');
    window.location.href='../register_admin.php'; 
    </script>"; 
   }
   exit;
?>