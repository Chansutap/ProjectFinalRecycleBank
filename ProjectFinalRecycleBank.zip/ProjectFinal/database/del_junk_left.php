<?php 
   include('data_config.php');
   
   $id = $_GET['id'];

   $del = "DELETE FROM left_junk WHERE id=$id";

   if(mysqli_query($mysqli,$del)){
    echo "<script>
    alert('ลบรีบร้อย !!!!');
    window.location.href='../junk_left_page.php'; 
    </script>"; 
   }
   else{
    echo "<script>
    alert('ไม่สามารถลบได้ !!!!');
    window.location.href='../junk_left_page.php'; 
    </script>"; 
   }
   exit;
?>