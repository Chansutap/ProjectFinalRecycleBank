<?php 
   include('data_config.php');
   
   $name = $_POST['name'];
   $phone = $_POST['phone'];
   $sex =  $_POST['sex'];
   $date = $_POST['date'];

   $select = "SELECT * FROM seller WHERE phone_sell='$phone'";
   $query = mysqli_query($mysqli,$select);

   if(mysqli_num_rows($query) <= 0){
    
       $insert = "INSERT INTO seller VALUES(NULL,'$name','$phone','$date','$sex')";

       if(mysqli_query($mysqli,$insert))
       {
          $select = "SELECT * FROM seller WHERE phone_sell='$phone'";
          $query = mysqli_query($mysqli,$select);
          $row = mysqli_fetch_array($query);

          $date = date("Y-m-d");
          $date2 = explode("-",$date);

          $d = $date2[2];
          $m = $date2[1];
          $y = ($date2[0]+543);

          $total_date = $y.'-'.$m.'-'.$d;

          $id = $row['id'];
          
          $insert = "INSERT INTO account_seller VALUES(NULL,0,0,0,'$total_date',$id)";
          if(mysqli_query($mysqli,$insert)){
             header("location:../list_member.php");
          }
          else{
            echo "<script>
            alert('กรอกข้อมูลให้ถูกต้อง !!!!');
            window.location.href='../list_member.php'; 
            </script>"; 
          }
          
       }
       else{
        echo "<script>
        alert('กรอกข้อมูลให้ถูกต้อง !!!!');
        window.location.href='../list_member.php'; 
        </script>"; 
       }
   }
   else{
    echo "<script>
    alert('มีข้อมูลลูกค้าคนนี้อยู่แล้ว !!!!');
    window.location.href='../list_member.php'; 
    </script>"; 

   }
   exit;
?>