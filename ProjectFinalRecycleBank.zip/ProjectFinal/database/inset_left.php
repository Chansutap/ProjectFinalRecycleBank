<?php 
   include('data_config.php');

$select = "SELECT * FROM product_junk ";
    $query = mysqli_query($mysqli,$select);
    if($query){
       while($row = mysqli_fetch_array($query)){
          $id = $row["id"];
          $insert = "INSERT INTO left_junk VALUES(NULL,$id,10)";
       //   mysqli_query($mysqli,$insert);
       } 
      
    }  
?>