<?php 
   include('data_config.php');
   
   $id = $_GET['id'];

   $del = "DELETE FROM seller WHERE id=$id";
   

   if(mysqli_query($mysqli,$del)){
      echo "<script>
      alert('ลบรีบร้อย !!!!');
      window.location.href='../list_member.php'; 
      </script>";   
   }
   else{
    echo "<script>
    alert('ไม่สามารถลบได้ !!!!');
    window.location.href='../list_member.php'; 
    </script>"; 
   }
   exit;
?>